package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BbsDAO {
	private Connection conn;
	private ResultSet rs;
	
	public BbsDAO() {
		try {
			String dbURL ="jdbc:mysql://localhost:3306/homepage";
			String dbID = "root";
			String dbPassword ="wjdqhqhdks";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String getDate() {
		String SQL="SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return ""; //�����ͺ��̽�����
	}
	
	public int getNext() {
		String SQL="SELECT num FROM board ORDER BY num DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1)+1;
			}
			return 1; //ù��° �Խù��� ���
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //������ ���̽� ����
	}
	public int write(String title, String writer, String content) {
		String SQL="INSERT INTO board VALUES (?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, title);
			pstmt.setString(3, writer);
			pstmt.setString(4, getDate());
			pstmt.setString(5, content);
			pstmt.setInt(6, 1);
			pstmt.setInt(7, 0);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //������ ���̽� ����
	}
	public ArrayList<Bbs> getList(int pageNumber) {
		String SQL="SELECT * FROM board WHERE num < ? AND available = 1 ORDER BY num DESC LIMIT 10";
		ArrayList<Bbs> list = new ArrayList<Bbs>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1)*10);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setNum(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setWriter(rs.getString(3));
				bbs.setReg_date(rs.getString(4));
				bbs.setContent(rs.getString(5));
				bbs.setAvailable(rs.getInt(6));
				bbs.setReadcount(rs.getInt(7));
				
				list.add(bbs);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list; //������ ���̽� ����
	}
	public boolean nextPage(int pageNumber) {//����¡ ó�� �Լ�
		String SQL="SELECT * FROM board WHERE num < ? AND available = 1 ORDER BY num DESC LIMIT 10";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1)*10);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false; //������ ���̽� ����
	}
	public Bbs getBbs(int num) {
		String SQL="SELECT * FROM board WHERE num =?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, num);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setNum(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setWriter(rs.getString(3));
				bbs.setReg_date(rs.getString(4));
				bbs.setContent(rs.getString(5));
				bbs.setAvailable(rs.getInt(6));
				bbs.setReadcount(rs.getInt(7));
				return bbs;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null; //������ ���̽� ����
	}
	
	public int update(int num, String title, String content) {
		String SQL="UPDATE board SET title=?, content =?, WHERE num =?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
	
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, num);

			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //������ ���̽� ����
	}
}
